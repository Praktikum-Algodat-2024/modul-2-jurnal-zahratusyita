import java.util.LinkedList;
import java.util.Queue;

public class LibraryQueue {
    private Queue<Borrower> queue;

    public LibraryQueue() {
        queue = new LinkedList<>();
    }

    public void addBorrower(Borrower borrower) {
        queue.add(borrower);
    }

    public void removeFirstBorrower() {
        queue.poll();
    }

    public void showQueue() {
        System.out.println("=================================================");
        System.out.println("=               DAFTAR ANTRIAN                  =");
        int position = 1;
        for (Borrower borrower : queue) {
            borrower.displayBorrower(position);
            position++;
        }
    }

    public void displayBorrowerBooks(String name) {
        for (Borrower borrower : queue) {
            if (borrower.getName().equalsIgnoreCase(name)) {
                borrower.displayBooks();
                return;
            }
        }
        System.out.println("Peminjam tidak ditemukan dalam antrian.");
    }

    public void swapQueue() {
        if (queue.size() >= 2) {
            Borrower first = queue.poll();
            Borrower second = queue.poll();
            queue.add(second);
            queue.add(first);
        }
    }

    public void processSpecialBooks() {
        Borrower currentBorrower = queue.peek();
        if (currentBorrower != null) {
            currentBorrower.removeNonSpecialBooks();
            currentBorrower.displayBooks();
        }
    }
}
