import java.util.Stack;

public class Main {
    public static void main(String[] args) {
        LibraryQueue libraryQueue = new LibraryQueue();

        //  Tambah antrian
        System.out.println("\n# Antrian Awal");

        Stack<Book> booksKazuma = new Stack<>();
        booksKazuma.push(new Book("Cara Menjadi Orang Kaya", "Teguh", "Fantasi", "Buku Biasa"));
        booksKazuma.push(new Book("Belajar Java", "Raysen", "Edukasi", "Buku Biasa"));
        libraryQueue.addBorrower(new Borrower("Kazuma", false, booksKazuma));

        Stack<Book> booksHuTao = new Stack<>();
        booksHuTao.push(new Book("Belajar Ilmu Hitam", "Megumin", "Unknown", "Cursed"));
        booksHuTao.push(new Book("Belajar C++", "Raysen", "Edukasi", "Buku Biasa"));
        libraryQueue.addBorrower(new Borrower("Hu Tao", true, booksHuTao));

        Stack<Book> booksKafka = new Stack<>();
        booksKafka.push(new Book("Cara Menjadi Milioner Dalam 1 Jam", "Optimus", "Edukasi", "Buku Biasa"));
        booksKafka.push(new Book("Misteri Menghilangnya Nasi Puyung", "Optimus", "Misteri", "Buku Biasa"));
        booksKafka.push(new Book("Raysen the Forgotten One", "Unknown", "Sejarah", "Cursed"));
        libraryQueue.addBorrower(new Borrower("Kafka", false, booksKafka));

        Stack<Book> booksXiangling = new Stack<>();
        booksXiangling.push(new Book("Cara Memasak", "Liyue", "Keseharian", "Buku Biasa"));
        libraryQueue.addBorrower(new Borrower("Xiangling", false, booksXiangling));

        libraryQueue.showQueue();

        libraryQueue.displayBorrowerBooks("Kazuma");

        //  Menghapus Kazuma dari antrian
        System.out.println("\n# Kazuma selesai");
        libraryQueue.removeFirstBorrower();
        libraryQueue.showQueue();

        // Menampilkan buku yang dipinjam oleh Hu Tao
        libraryQueue.displayBorrowerBooks("Hu Tao");

        //  Menghapus Hu Tao dari antrian
        System.out.println("\n# Hu Tao Selesai");
        libraryQueue.removeFirstBorrower();
        libraryQueue.showQueue();

        //  Menambah Sucrose ke dalam antrian
        Stack<Book> booksSucrose = new Stack<>();
        booksSucrose.push(new Book("Durin The Forgotten Dragon", "Gold", "Misteri", "Buku Biasa"));
        booksSucrose.push(new Book("Alhcemy", "Albedo", "Sains", "Cursed"));
        booksSucrose.push(new Book("Resurrection", "Unknown", "Unknown", "Cursed"));
        libraryQueue.addBorrower(new Borrower("Sucrose", true, booksSucrose));
        libraryQueue.showQueue();

        //  Menghapus Xiangling dari antrian
        libraryQueue.removeFirstBorrower();
        libraryQueue.showQueue();

        //  Menukar posisi Kafka dengan Sucrose
        System.out.println("\n# Langkah 8: Menukar posisi Kafka dengan Sucrose");
        libraryQueue.swapQueue();
        libraryQueue.showQueue();

        //  Menampilkan buku yang dipinjam oleh Sucrose
        libraryQueue.displayBorrowerBooks("Sucrose");

        //  Menghapus Sucrose dari antrian
        System.out.println("\n# Sucrose selesai");
        libraryQueue.removeFirstBorrower();
        libraryQueue.showQueue();

        //  Menampilkan buku yang dipinjam oleh Kafka
        libraryQueue.displayBorrowerBooks("Kafka");

        System.out.println("\n# haspus buku terkutuk");
        libraryQueue.processSpecialBooks();

        // Kafka keluar dari antrian
        System.out.println("\n# Kafka keluar");
        libraryQueue.removeFirstBorrower();
        libraryQueue.showQueue();
    }
}
