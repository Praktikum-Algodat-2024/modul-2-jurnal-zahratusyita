public class Book {
    private String title;
    private String author;
    private String genre;
    private String status;

    public Book(String title, String author, String genre, String status) {
        this.title = title;
        this.author = author;
        this.genre = genre;
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public void displayBook() {
        System.out.println("=================================================");
        System.out.println("Judul Buku\t: " + title);
        System.out.println("Pengarang\t: " + author);
        System.out.println("Genre\t\t: " + genre);
        System.out.println("Status Buku\t: " + status);
    }
}
