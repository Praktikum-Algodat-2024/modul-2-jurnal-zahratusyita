import java.util.Stack;

public class Borrower {
    private String name;
    private boolean specialCard;
    private Stack<Book> borrowedBooks;

    public Borrower(String name, boolean specialCard, Stack<Book> borrowedBooks) {
        this.name = name;
        this.specialCard = specialCard;
        this.borrowedBooks = borrowedBooks;
    }

    public boolean hasSpecialCard() {
        return specialCard;
    }

    public String getName() {
        return name;
    }

    public void displayBorrower(int queueNumber) {
        System.out.println("=================================================");
        System.out.println("Nama\t\t: " + name);
        System.out.println("Antrian ke\t: " + queueNumber);
        System.out.println("Jumlah Buku\t: " + borrowedBooks.size());
        System.out.println("Kartu Spesial\t: " + (specialCard ? "Ada" : "Tidak ada"));
    }

    public void displayBooks() {
        System.out.println("=================================================");
        System.out.println("=               BUKU " + name.toUpperCase() + "                  =");
        for (Book book : borrowedBooks) {
            book.displayBook();
        }
    }

    public void removeNonSpecialBooks() {
        borrowedBooks.removeIf(book -> book.getStatus().equals("Cursed") && !specialCard);
    }
}
